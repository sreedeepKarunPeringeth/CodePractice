package com.spring.SpringQuickStart;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringQuickStartApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringQuickStartApplication.class, args);
	}
}
