package com.spring2.SpringQuickStartNotBoot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringQuickStartNotBootApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringQuickStartNotBootApplication.class, args);
	}
}
