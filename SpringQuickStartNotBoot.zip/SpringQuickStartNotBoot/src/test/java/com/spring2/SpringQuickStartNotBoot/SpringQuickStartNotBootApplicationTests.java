package com.spring2.SpringQuickStartNotBoot;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest
public class SpringQuickStartNotBootApplicationTests {

	@Test
	public void contextLoads() {
	}

}
